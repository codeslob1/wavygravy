use std::rc::Rc;
use std::cell::RefCell;
use std::io::{Error, ErrorKind};
use std::path::PathBuf;
use crate::{AnaSigGen, DigiSigGen, DigiWave, Result, Sampler, SineGen};
use wavefmt::{FieldType, WaveFile};

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum FileType {
    TryAny,
    AlbBin,
}
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum SigType {
    Digital,
    Analog,
}

pub struct DataStore {
    sigs   : Vec<(SigType, usize)>,
    digsam : Vec<Rc<RefCell<dyn Sampler<bool>>>>,
    anasam : Vec<Rc<RefCell<dyn Sampler<f32>>>>,
    ws_alb : Vec<Rc<RefCell<wavefmt::AlbBinFile>>>,
}

impl Default for DataStore {
    fn default() -> Self {
        Self {
            sigs   : Vec::new(),
            digsam : Vec::new(),
            anasam : Vec::new(),
            ws_alb : Vec::new(),
        }
    }
}

impl DataStore {
    pub fn new() -> Self {
        Default::default()
    }

    pub fn load_wave(&mut self, path: PathBuf, ftype: FileType) -> Result<()> {
        match ftype {
            FileType::AlbBin => {
                let wavenum = self.ws_alb.len();
                let digsam_len = self.digsam.len();
                let mut digsam_stack : Vec<usize> = Vec::new();
                let mut alb = wavefmt::AlbBinFile::new(path)?;
                let ok = alb.check_format()?;
                for fld in 0..alb.get_num_fields() {
                    let fldinfo = alb.get_field_info(fld);
                    match fldinfo.ftype {
                        FieldType::Digital => {
                            // Push field indexes now, fix up with wave refcell later
                            let samidx = digsam_len + digsam_stack.len();
                            digsam_stack.push(fld);
                        }
                        FieldType::Timestamp => {} // Ignore
                        _ => {
                            let msg = format!("Bad field type {:?}", fldinfo.ftype);
                            return Err(Box::new(Error::new(ErrorKind::Unsupported, msg)));
                        }
                    }
                }
                let alb_rc = Rc::new(RefCell::new(alb));
                self.ws_alb.push(Rc::clone(&alb_rc));
                for fld in digsam_stack {
                    let smpl : Rc<RefCell<dyn Sampler<bool>>> = Rc::new(RefCell::new(DigiWave::new(alb_rc.clone(), fld)));
                    self.sigs.push((SigType::Digital, self.digsam.len()));
                    self.digsam.push(smpl);
                }
                Ok(())
            }
            _ => {
                let msg = format!("File type: {:?}", ftype);
                return Err(Box::new(Error::new(ErrorKind::Unsupported, msg)));
            }
        }
    }

    pub fn new_test() -> Self {
        use SigType::*;
        let mut sigs   : Vec<(SigType, usize)> = Vec::new();
        let mut digsam : Vec<Rc<RefCell<dyn Sampler<bool>>>> = Vec::new();
        let mut anasam : Vec<Rc<RefCell<dyn Sampler<f32>>>> = Vec::new();
        let sigtypes : [SigType; 12] = [
            Digital, Analog, Digital, Digital, Digital, Analog, Digital, Digital, Digital, Digital, Digital, Digital,
        ];
        for _n in 0..5 {
            for (sig,sigtype) in sigtypes.into_iter().enumerate() {
                let samidx = if sigtype == Digital {
                    let cur = digsam.len();
                    let smpl : Rc<RefCell<dyn Sampler<bool>>> = match sig % 12 {
                        0 => if sig < 12 { Rc::new(RefCell::new(DigiSigGen::new_clock(sig, 1000000.))) }
                             else { Rc::new(RefCell::new(DigiSigGen::new_fixed(sig, false))) },
                        1 | 5 | 6 | 7 => Rc::new(RefCell::new(DigiSigGen::new_fixed(sig, true))),
                        3 => Rc::new(RefCell::new(DigiSigGen::new_pulse(sig, 57000000., 58000000., 8000000.))),
                        9 => Rc::new(RefCell::new(DigiSigGen::new_pulse(sig, 10000000., 99000000., 8000000.))),
                        _ => Rc::new(RefCell::new(DigiSigGen::new_fixed(sig, false))),
                    };
                    digsam.push(smpl);
                    cur
                } else {
                    let cur = anasam.len();
                    let smpl : Rc<RefCell<dyn Sampler<f32>>> = match anasam.len() {
                        0 => Rc::new(RefCell::new(SineGen::new(sig, 15., 0., 500000.))),
                        1 => Rc::new(RefCell::new(AnaSigGen::new_pulse(sig, 0., 10., 57000000., 58000000., 8000000.))),
                        _ => Rc::new(RefCell::new(AnaSigGen::new_fixed(sig, 0.5))),
                    };
                    anasam.push(smpl);
                    cur
                };
                sigs.push((sigtype, samidx));
            }
        }
        Self {
            sigs,
            digsam,
            anasam,
            ws_alb: Vec::new(),
        }
    }

    /// Get maximum start, end time of all waveforms
    pub fn get_range(&self) -> (f64, f64) {
        let mut start = 0.0f64;
        let mut end = 0.0f64;

        for w in self.ws_alb.iter() {
            let (tstart, tend) = w.borrow().get_range();
            if start > tstart { start = tstart; }
            if end < tend { end = tend; }
        }
        (start, end)
    }

    pub fn get_num_signals(&self) -> usize {
        self.sigs.len()
    }

    pub fn get_signal_ypos(&self, sig: usize) -> f64 {
        let mut acc = 0.;
        for _n in 0..(sig-1) {
            let (sigtype, _) = self.get_signal_type_idx(sig);
            acc += if sigtype == SigType::Digital { crate::HEIGHT_DIGITAL } else { crate::HEIGHT_ANALOG }
        }
        acc
    }

    pub fn get_signal_type_idx(&self, sig: usize) -> (SigType, usize) {
        self.sigs[sig]
    }

    pub fn get_dig_sampler(&mut self, didx: usize, idx: usize) -> Option<&mut RefCell<dyn Sampler<bool>>> {
        Rc::get_mut(&mut self.digsam[didx])
    }

    pub fn get_ana_sampler(&mut self, aidx: usize, sig: usize) -> Option<&mut RefCell<dyn Sampler<f32>>> {
        Rc::get_mut(&mut self.anasam[aidx])
    }
}

