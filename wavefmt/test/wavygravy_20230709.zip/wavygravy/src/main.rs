use wavygravy::Result;

fn main() -> Result<()> {
    wavygravy::main()
}
