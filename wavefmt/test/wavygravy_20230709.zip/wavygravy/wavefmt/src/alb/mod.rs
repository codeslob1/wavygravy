//use std::sync::Lazy;

//use std::io;
use std::error;
use std::io::prelude::*;
use std::io::{BufReader, Error, ErrorKind, SeekFrom};
use std::fs::File;
use std::path::PathBuf;
use std::collections::HashMap;
//use std::mem;
//use byteorder::{ByteOrder, LittleEndian};

use super::{FieldInfo, FieldType, NumType, WaveFile};

type Result<T> = std::result::Result<T, Box<dyn error::Error>>;

/// Extend field info with required information to extract binary field data
#[derive(Debug)]
struct AlbFieldInfo {
    fi : FieldInfo,
    numtype: NumType,
    bytepos: usize,
    bytesize: usize,
    bitmask: u64,
}

impl AlbFieldInfo {
    /// Extract field data (u8)
    fn extract_u8(&self, buf: &[u8]) -> u8 {
        let slice = &buf[self.bytepos..self.bytepos+self.bytesize];
        slice[0] & (self.bitmask as u8)
    }

    /// Extract field data (u16)
    fn extract_u16(&self, buf: &[u8]) -> u16 {
        let slice = &buf[self.bytepos..self.bytepos+self.bytesize];
        let mut bytes : [u8; 2] = [0; 2];
        bytes.copy_from_slice(slice);
        u16::from_le_bytes(bytes) & (self.bitmask as u16)
    }

    /// Extract field data (u32)
    fn extract_u32(&self, buf: &[u8]) -> u32 {
        let slice = &buf[self.bytepos..self.bytepos+self.bytesize];
        let mut bytes : [u8; 4] = [0; 4];
        bytes.copy_from_slice(slice);
        u32::from_le_bytes(bytes) & (self.bitmask as u32)
    }

    /// Extract field data (u64)
    fn extract_u64(&self, buf: &[u8]) -> u64 {
        let slice = &buf[self.bytepos..self.bytepos+self.bytesize];
        let mut bytes : [u8; 8] = [0; 8];
        bytes.copy_from_slice(slice);
        u64::from_le_bytes(bytes) & self.bitmask
    }

    /// Extract field data (f64)
    fn extract_f64(&self, buf: &[u8]) -> f64 {
        let slice = &buf[self.bytepos..self.bytepos+self.bytesize];
        let mut bytes : [u8; 8] = [0; 8];
        bytes.copy_from_slice(slice);
        f64::from_le_bytes(bytes)
    }
}

#[derive(Debug)]
pub struct AlbBinFile {
    path: PathBuf,
    reader: BufReader<File>,
    //hdr: String,
    trigger_row: usize,
    num_rows: usize,
    fields: Vec<AlbFieldInfo>,
    timestamp_field : Option<String>,
    timestamp_idx : usize,
    colmap: HashMap<String, usize>,
    record_len: usize,
    data_start: u64,
    time_start: f64,
    time_end: f64,
    readpos: usize,
}

impl AlbBinFile {
    pub fn new(path: PathBuf) -> Result<Self> {
        let file = File::open(path.as_path())?;
        let reader = BufReader::new(file);
        Ok(Self {
            path,
            reader,
            //hdr: String::new(),
            trigger_row: 0,
            num_rows: 0,
            fields: Vec::new(),
            timestamp_field: None,
            timestamp_idx : usize::MAX, // Invalid value
            colmap: HashMap::new(),
            record_len: 0,
            data_start: 0,
            time_start: 0.0,
            time_end: 0.0,
            readpos: 0,
        })
    }
    
    /// Check the wave file matches the expected format
    /// Leaves the file position at the start of binary data section
    fn read_header(&mut self) -> Result<String> {
        const MAGIC : &'static str = "AGILENT_BINARY_DATA";
        const TERM : &'static str = "HEADER_END";

        let mut header_found = false;
        let mut hdr : String = String::new();
        let mut lines : usize = 0;
        while lines < 256 {
            let pos = hdr.len();
            let _cnt = self.reader.read_line(&mut hdr)?;
            println!("line[{}..{}] {} [{}]: {}", pos, pos+_cnt, hdr.len(), 
                     self.reader.stream_position()?, &hdr[pos..pos+_cnt]);

            // Check first line matches (sanity check format)
            if lines == 0 && !hdr[pos..].starts_with(MAGIC) {
                return Err(Box::new(Error::new(ErrorKind::NotFound, "")));
            }

            // Check for last line of header
            if hdr[pos..].starts_with(TERM) {
                header_found = true;
                break;
            }

            lines += 1;
        }
        if header_found {
            // Save data start position
            self.data_start = self.reader.stream_position()?;
            Ok(hdr)
        } else { 
            Err(Box::new(Error::new(ErrorKind::NotFound, "")))
        }
    }

    /// Process the wave file header
    fn process_header(&mut self, hdr: String) -> Result<()> {
        println!("Hdr: {}", hdr);

        // Byte position of current column in wave data
        let mut bytepos = 0;

        for line in hdr.lines() {
            let fields_str = parse_fields(&line);
            //println!("fields: {:?}", fields_str);
            if fields_str.len() > 1 && fields_str[0] == "TIME_SOURCE" {
                if fields_str[1].starts_with("COLUMN=") {
                    let fieldname = strip_quotes(&fields_str[1][7..]);
                    self.timestamp_field = Some(fieldname.to_string());
                }
            }
            if fields_str[0].starts_with("NUM_ROWS=") {
                let val = &fields_str[0][9..].parse::<i64>()?;
                self.num_rows = *val as usize;
            }
            if fields_str.len() > 1 && fields_str[0] == "COLUMN" {
                let name = strip_quotes(fields_str[1]);
                let mut coltype : &str = "";
                let mut vartype : &str = "";
                let mut nbytes : usize = 0;
                let mut width_bits : usize = 0;
                for fld in &fields_str[2..] {
                    //println!("fld {}", fld);
                    if *fld == "VALUE" || *fld == "SAMPLE_NUMBER" || *fld == "TIME" { coltype = fld; }
                    else if *fld == "FLOAT" || *fld == "UNSIGNED_INTEGER" || *fld == "INTEGER" { vartype = fld; }
                    
                    // Field size (bytes)
                    else if fld.starts_with("NBYTES=") {
                        let val = &fld[7..].parse::<i32>()?;
                        nbytes = *val as usize;
                        //println!("nbytes {}", nbytes);
                    
                    // Field width (bits)
                    } else if fld.starts_with("WIDTH_BITS=") {
                        let val = &fld[11..].parse::<i32>()?;
                        width_bits = *val as usize;
                        //println!("width_bits {}", width_bits);

                    // Check byte order is LE
                    } else if fld.starts_with("BYTE_ORDER=") {
                        if "LITTLE_ENDIAN" != &fld[11..] {
                            return Err(Box::new(Error::new(ErrorKind::Unsupported, "")));
                        }
                    }
                }
                if coltype == "VALUE" || coltype == "TIME" {
                    let ftype = if coltype == "TIME" {
                        FieldType::Timestamp
                    } else {
                        FieldType::Digital  // LA always produces digital data
                    };
                    let numtype = match vartype {
                        "FLOAT"            => NumType::Float,
                        "UNSIGNED_INTEGER" => NumType::UnsignedInteger,
                        "INTEGER"          => NumType::Integer,
                        _                  => NumType::Unknown,
                    };
                    let fi = FieldInfo {
                        name: name.to_string(),
                        ftype, 
                    };
                    let field = AlbFieldInfo {
                        fi,
                        numtype,
                        bytepos: bytepos,
                        bytesize: nbytes,
                        bitmask: (1u64<<width_bits) - 1,
                    };
                    println!("col name:{} ftype:{:?} bytepos:{} bytesize:{} bitmask:{:02X}", 
                             field.fi.name, field.fi.ftype,
                             field.bytepos, field.bytesize, field.bitmask);
                    self.colmap.insert(field.fi.name.to_string(), self.fields.len());
                    self.fields.push(field);
                }
                bytepos += nbytes;
            }
        }

        // Save data start position and record length
        self.record_len = bytepos;

        println!("Found record size {} fields, {} bytes per row, {} rows", self.fields.len(), self.record_len, self.num_rows);

        Ok(())
    }

    /// Check the wave file matches the expected format
    fn read_timestamps(&mut self) -> Result<()> {
        let err = Box::new(Error::new(ErrorKind::NotFound, ""));

        // If there was a TIME_SOURCE field, read the start and end timestamp values
        let idx : usize = if let Some(ts_field) = &self.timestamp_field {
            if let Some(idx) = self.colmap.get(ts_field) { *idx } else { return Err(err); }
        } else {
            return Err(err);
        };
        self.timestamp_idx = idx;

        let mut buf : Vec<u8> = Vec::with_capacity(self.record_len);
        buf.resize(self.record_len, 0);

        self.read_record(&mut buf)?;
        let ts_fld = &self.fields[idx];
        self.time_start = ts_fld.extract_f64(&buf);
        self.seek_record(self.num_rows-1)?;
        self.read_record(&mut buf)?;
        let ts_fld = &self.fields[idx];
        self.time_end = ts_fld.extract_f64(&buf);
        println!("time start: {}", self.time_start);
        println!("time end: {}", self.time_end);
        println!("data start: {}", self.data_start);
        self.seek_record(0)?;

        Ok(())
    }

    /// Extract time field
    pub fn extract_time(&self, buf: &[u8]) -> Option<f64> {
        if self.timestamp_idx < usize::MAX {
            let ts_fld = &self.fields[self.timestamp_idx];
            Some(ts_fld.extract_f64(&buf))
        } else { None }
    }

    /// Extract data field
    pub fn extract_bool(&self, buf: &[u8], sig: usize) -> bool {
        let fld = &self.fields[sig];
        match fld.bytesize {
            1 => fld.extract_u8(buf) != 0,
            2 => fld.extract_u16(buf) != 0,
            4 => fld.extract_u32(buf) != 0,
            _ => false,
        }
    }

    /// Read the record at the current position
    pub fn read_record(&mut self, buf: &mut Vec<u8>) -> Result<()> {
        self.reader.read_exact(buf)?;
        self.readpos += 1;
        Ok(())
    }

    /// Seek to the start of a specific record number (row)
    pub fn seek_record(&mut self, idx: usize) -> Result<()> {
        let seekoffs = self.data_start + (idx * self.record_len) as u64;
        //println!("seek {} -> {}", idx, seekoffs);
        self.reader.seek(SeekFrom::Start(seekoffs))?;
        self.readpos = idx;
        Ok(())
    }

    pub fn get_readpos(&self) -> usize { self.readpos }

//    /// Return header as string for debug
//    pub(crate) fn get_header(&self) -> String {
//        self.hdr.clone()
//    }
}

/// Parse whitespace-separated fields with quoted fields and whole-line comments
fn parse_fields<'a>(s: &'a str) -> Vec<&'a str> {
    let mut arr : Vec<&str> = Vec::new();

    #[derive(Debug, Clone, Copy)]
    enum State {
        Idle,
        Quotes,
        Value,
    }

    let mut ss : State = State::Idle;
    let mut first = usize::MAX;

    for (idx,ch) in s.chars().enumerate() {
        let next_ss = match ss {
            State::Idle => {
                if ch.is_whitespace() {
                    ss
                } else if ch == '#' {
                    first = idx;
                    break; // Take to end of line (comment)
                } else if ch == '"' {
                    first = idx;
                    State::Quotes
                } else {
                    first = idx;
                    State::Value
                }
            }
            State::Quotes => {
                if ch == '"' {
                    arr.push(&s[first..=idx]);
                    first = usize::MAX;
                    State::Idle
                } else { ss }
            }
            State::Value => {
                if ch.is_whitespace() {
                    //println!("arr push [{}..{}]", first, idx);
                    arr.push(&s[first..idx]);
                    first = usize::MAX;
                    State::Idle
                } else { ss }
            }
        };
        //println!("ss:{:?} idx:{} ch:{} -> next_ss:{:?}", ss, idx, ch, next_ss);

        ss = next_ss;
    }

    if first != usize::MAX {
        arr.push(&s[first..]);
    }

    arr
}

/// Adjust str to skip leading/training quote marks
fn strip_quotes<'a>(s: &'a str) -> &'a str {
    s.trim_start_matches('"').trim_end_matches('"')
}

impl WaveFile for AlbBinFile {
    /// Check the wave file matches the expected format
    fn check_format(&mut self) -> Result<bool> {
        let hdr = self.read_header()?;
        self.process_header(hdr)?;
        self.read_timestamps()?;
        Ok(true)
    }

    /// Size (in bytes) of wave record
    fn get_record_size(&self) -> Option<usize> {
        Some(self.record_len)
    }

    /// Return time range covered by this waveform
    fn get_range(&self) -> (f64, f64) {
        //println!("get_range : range ({},{})", self.time_start, self.time_end);
        (self.time_start, self.time_end)
    }

    /// Return number of fields, requires check_format is called first to read file header
    fn get_num_fields(&self) -> usize {
        self.fields.len()
    }

    /// Return field details, requires check_format is called first to read file header
    fn get_field_info(&self, field: usize) -> &FieldInfo {
        &self.fields[field].fi
    }

    /// Return number of rows (data points) if available, requires check_format is called first to read file header
    fn get_num_rows(&self) -> Option<usize> {
        Some(self.num_rows)
    } 

    /// Prepare to display a range of waveform data, return (start, end) record number for this
    /// time range
    #[inline(never)]
    fn prepare_iter_range(&mut self, range: &[f64; 2]) -> Result<[usize; 2]> {
        let mut start : usize = 0;
        let mut end : usize = usize::MAX;
        let mut buf : Vec<u8> = Vec::with_capacity(self.record_len);
        buf.resize(self.record_len, 0);

        // Sanity check we should have already called self.read_timestamps() to capture self.timestamp_idx
        assert!(self.timestamp_idx < usize::MAX);

        self.seek_record(0)?;
        let mut idx = 0;

        // Find first index inside time range
        while idx < self.num_rows {
            //println!("f#{}", idx);
            self.read_record(&mut buf)?;
            let time = self.extract_time(&buf).unwrap();
            if time > range[0] {
                start = idx;
                break;
            }
            idx += 1;
        }

        // Maybe need to seek back to previous record
        self.seek_record(idx)?;

        // Find last index inside time range
        let mut last_idx = idx;
        while idx < self.num_rows {
            //println!("l#{} / {} [{}]", idx, self.num_rows, self.get_readpos());
            self.read_record(&mut buf)?;
            let time = self.extract_time(&buf).unwrap();
            if time > range[1] {
                end = last_idx;
                break;
            }
            last_idx = idx;
            idx += 1;
        }

        // Last row in waveform is inside time range, use that for end index
        if idx == self.num_rows { end = idx-1; }

        //println!("f:{} l:{}", start, end);

        // Seek to first record in iter range, for display
        self.seek_record(start)?;

        let sample_bounds : [usize; 2] = [start, end];
        Ok(sample_bounds)
    }
}
