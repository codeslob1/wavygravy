use super::*;

#[test]
fn load_alb() {
    let mut alb = AlbBinFile::new("test/nand_erase.alb".into()).unwrap();
    assert!(alb.check_format().unwrap());
}
